export const API_URL={
    BASE_URI:"http://localhost:5078",
    GET_ALL_ARTICLES_URN:"/api/News/GetAllNewsArticle?FilterValue={filterValue}&Skip={pageNumber}&Take={pageSize}",
    CREATE_ARTICLE_URN:"/api/News/CreateNewsArticle",
    UPDATE_ARTICLE_URN:"/api/News/UpdateNewsArticle?id={id}",
    DELETE_ARTICLE_URN:"/api/News/DeleteNewsArticle?id={id}",
    GET_ALL_CATEGORIES_URN:"/api/News/GetCategories"
}