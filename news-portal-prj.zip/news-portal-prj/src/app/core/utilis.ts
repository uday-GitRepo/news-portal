export const replacePlaceholder=(template:string, values:Record<string,any>):string=>{
    return Object.keys(values).reduce((result, token) => {
        const regex = new RegExp(`{${token}}`, 'g');
        return result.replace(regex, values[token]);
      }, template);
}