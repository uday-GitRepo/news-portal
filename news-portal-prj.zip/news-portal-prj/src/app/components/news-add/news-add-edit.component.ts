import { Component, OnInit, Input,Output,EventEmitter, OnChanges } from '@angular/core';
import { Validators, FormGroup, FormControl } from '@angular/forms';
import {MessageService} from 'primeng/api';
import { category } from 'src/app/models/category';
import { NewsService } from '../../services/news.service';
import { NewsArticle } from '../../models/news';
@Component({
  selector: 'app-news-add-edit',
  templateUrl: '././news-add-edit.component.html',
  styleUrls: ['././news-add-edit.component.css']
})
export class NewsAddEditComponent implements OnInit, OnChanges {
  
  @Input() displayAddModal:boolean=true;
  @Output() clickClose:EventEmitter<boolean>=new EventEmitter<boolean>();
  @Output() clickAdd:EventEmitter<NewsArticle>=new EventEmitter<NewsArticle>();
  @Input() selectedNewsArticle!:NewsArticle;
  categories:category[]=[{categoryId:1, categoryName:"Default"}];  
  dialogMode:string="Add";
  loading:boolean=false;
  constructor(private messageService:MessageService,private newsService: NewsService) { }  

    newsForm:FormGroup=new FormGroup({
    title: new FormControl("", [Validators.required, Validators.maxLength(50)]),
    description: new FormControl("", [Validators.required]),
    categoryId: new FormControl("", [Validators.required])
  }); 

  ngOnInit(): void {
      
    this.getCategories();  
  }

  ngOnChanges():void
  {
    if(this.selectedNewsArticle)
    {
      this.dialogMode="Edit";
      this.newsForm.patchValue(this.selectedNewsArticle);
    }
    else
    {
      this.dialogMode="Add";
      this.newsForm.reset();
    }
  }

  getCategories(): void {
    this.newsService.getCategories().subscribe((category:category[]) => {
      this.categories = category
    });
  }

  closeModal()
  {    
    this.newsForm.reset();
    this.clickClose.emit(true);
  } 

  findElement(value:number):any
  {    
    const found = this.categories.find((obj) => {
      return obj.categoryId === value;
    });

    return found?.categoryName
  }

  addEditNewsArticle()
  {    
      if(this.newsForm.valid)
      {
          this.loading=true;
          let resonse=null;
          let article:NewsArticle;
          if(this.dialogMode=="Add")
              resonse=this.newsService.addNewsArticles(this.newsForm.value);
            else 
            {
              article={...this.newsForm.value,id:this.selectedNewsArticle.id};
              resonse=this.newsService.updateNewsArticles(article);
            }

            resonse.subscribe((articlesResponse:NewsArticle) => {

              let categoryName=this.findElement(Number(this.newsForm.value.categoryId));
                if(this.dialogMode=="Edit") 
                    articlesResponse={...article,categoryName:categoryName, createdOn:this.selectedNewsArticle.createdOn};
                else articlesResponse={...articlesResponse,categoryName:categoryName};

                this.clickAdd.emit(articlesResponse);
                this.closeModal();  
                this.loading=false; 
                this.messageService.add({severity:'success', summary:'Success', detail:`Record ${this.dialogMode=="Add" ? "Added" : "Updated"} successfully`});
                
            }, (error)=>{
              this.loading=false;
              this.messageService.add({severity:'error', summary:'Failed', detail:error.message});
            });
          }   
      }

}
