import { Component } from '@angular/core';
import { NewsArticle } from '../../models/news';
import { NewsService } from '../../services/news.service';
import { ConfirmationService } from 'primeng/api';
import {MessageService} from 'primeng/api';
import { LazyLoadEvent } from 'primeng/api';
@Component({
  selector: 'news-list',
  templateUrl: './news-list.component.html',
  styleUrls: ['./news-list.component.css']
})
export class NewsListComponent {
  newsArticles: NewsArticle[] = [];
  displayAddEditModal:boolean=false;
  selectedNewsArticle:any;
  dataTotalRecords:number=0;
  loading: boolean=false;
  pageNumber:number=1;
  pageSize:number=5;
  filterText:string="";
  constructor(private messageService:MessageService,private newsService: NewsService,private confirmationService: ConfirmationService){}


    onFilterClick(filterValue:string)
    {
      this.filterText=filterValue;
      this.getNews(filterValue,0,5);
    }
    showDialog() 
    {
      this.selectedNewsArticle=null;
      this.displayAddEditModal=true;
    }

    hideAddModal(isClosed:boolean)
    {
      this.displayAddEditModal=!isClosed;
    }

    ngOnInit(): void {
      
    }

    onPageChange(event: any) {
      this.pageNumber=(event.first / event.rows) + 1;      
    }

  getNews(filterValue:string,pageNumber:number,pageSize:number=5): void {
    this.loading=true;
    this.newsService.getNewsArticles(filterValue,pageNumber,pageSize).subscribe((articles:any) => {
      this.newsArticles = articles.newArticleDetails;      
      this.dataTotalRecords=Number(articles.totalRecords);
      this.loading=false;
    });
  }

  loadDataLazy(event: LazyLoadEvent) {
   
    let first=event.first?? 0;
    let rows=event.rows ?? 0;
    this.getNews(this.filterText,((first / rows) + 1),this.pageSize);
  }

  saveArticleToList(article:NewsArticle)
  {
      if(this.selectedNewsArticle)
      {
        const index=this.newsArticles.findIndex(n=>n.id==this.selectedNewsArticle.id);
        this.newsArticles[index]=article;
      }
      else this.newsArticles.unshift(article);
  }

  showEditDialog(article:NewsArticle)
  {
    this.displayAddEditModal=true;
    this.selectedNewsArticle=article;
    
  }

  confirm(news:NewsArticle) {
    this.confirmationService.confirm({
        message: 'Are you sure that you want to perform this action?',        
        accept: () => {
          this.newsService.deleteNewsArticles(news.id).subscribe((articles:any) => {
            this.newsArticles=this.newsArticles.filter(a=>a.id!==news.id);
            this.messageService.add({severity:'success', summary:'Success', detail:'record deleted successfully.'}); 
          },(error:any)=>{
            this.messageService.add({severity:'error', summary:'Failed', detail:error.message});
          });
        }
    });
}
}
