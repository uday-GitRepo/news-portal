import { Injectable } from '@angular/core';
import {HttpClient} from '@angular/common/http'
import { NewsArticle } from '../models/news';
import { Observable, map } from 'rxjs';
import { category } from '../models/category';
import { API_URL } from '../core/constants';
import { replacePlaceholder } from '../core/utilis';

@Injectable({
  providedIn: 'root'
})

export class NewsService {

  constructor(private _http:HttpClient) { }
  private finalURL="";
  getNewsArticles(filterValue:string,pageNumber:number,pageSize:number=5):Observable<NewsArticle[]>
  {
    this.finalURL=replacePlaceholder(`${API_URL.BASE_URI}${API_URL.GET_ALL_ARTICLES_URN}`,{filterValue,pageNumber,pageSize});
    return this._http.get<NewsArticle[]>(this.finalURL);    
  }

  getCategories():Observable<category[]>
  {
    return this._http.get<category[]>(`${API_URL.BASE_URI}${API_URL.GET_ALL_CATEGORIES_URN}`);    
  }

  addNewsArticles(newsArticles:NewsArticle):Observable<NewsArticle>
  {
    return this._http.post<NewsArticle>(`${API_URL.BASE_URI}${API_URL.CREATE_ARTICLE_URN}`,newsArticles);    
  }

  updateNewsArticles(newsArticles:NewsArticle):Observable<NewsArticle>
  {
    this.finalURL=replacePlaceholder(`${API_URL.BASE_URI}${API_URL.UPDATE_ARTICLE_URN}`,{id:newsArticles.id});   
    return this._http.put<NewsArticle>(this.finalURL,newsArticles);    
  }

  deleteNewsArticles(id:number):any
  {
    this.finalURL=replacePlaceholder(`${API_URL.BASE_URI}${API_URL.DELETE_ARTICLE_URN}`,{id}); 
    return this._http.delete(this.finalURL);    
  }
}
