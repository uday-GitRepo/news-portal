export class NewsArticle {
    id: number;
    title: string;
    description: string;
    categoryId:number;
    categoryName:string;
    createdOn: Date;
  
    constructor(
      id: number,
      title: string,
      description: string,
      categoryId: number,
      categoryName:string,
      createdOn: Date
    ) {
      this.id = id;
      this.title = title;
      this.description = description;
      this.categoryId = categoryId;
      this.categoryName=categoryName;
      this.createdOn=createdOn
    }
  }
  