﻿namespace News_Portal_API.DTOs
{
    public class GeCategoryDto
    {
        public int CategoryId { get; set; }
        public string CategoryName { get; set; } = null!;
    }
}
