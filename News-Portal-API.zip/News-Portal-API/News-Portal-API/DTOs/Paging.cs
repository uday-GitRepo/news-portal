﻿namespace News_Portal_API.DTOs
{
    public class Paging
    {
        public string? FilterValue { get; set; }
        public int Skip { get; set; }
        public int Take { get; set; }
    }
}
