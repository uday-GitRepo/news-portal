﻿namespace News_Portal_API.DTOs
{
    public class NewArticleDetailsDto
    {
        public int Id { get; set; }

        public string Title { get; set; } = string.Empty;

        public string Description { get; set; } = string.Empty;

        public int CategoryId { get; set; } 

        public string CategoryName { get; set; } = string.Empty;

        public DateTime CreatedOn { get; set; }
    }

    public class GetNewArticleDetailsDto
    {
        public List<NewArticleDetailsDto>? NewArticleDetails { get; set; } = null;
        public int TotalRecords { get; set; }
    }

}
