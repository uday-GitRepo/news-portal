using Microsoft.EntityFrameworkCore;
using News_Portal_API.Configuration;
using News_Portal_API.Contracts;
using News_Portal_API.Middlewares;
using News_Portal_API.Models;
using News_Portal_API.Repository;
using Serilog;

var builder = WebApplication.CreateBuilder(args);

var connectionString = builder.Configuration.GetConnectionString("NewsArticleStore");


Log.Logger = new LoggerConfiguration().CreateBootstrapLogger();
builder.Host.UseSerilog(((ctx,lc)=> lc.ReadFrom.Configuration(ctx.Configuration)));

            

// Add services to the container.
builder.Services.AddDbContext<NewsArticleContext>(options =>
{
    options.UseSqlServer(connectionString);
});
builder.Services.AddScoped<INewsArticleRepository, NewsArticleRepository>();
builder.Services.AddScoped<ICategoryRepository, CategoryRepository>();
builder.Services.AddMemoryCache();
builder.Services.AddControllers();
builder.Services.AddAutoMapper(typeof(MapperConfig));
builder.Services.AddEndpointsApiExplorer();
builder.Services.AddSwaggerGen();
builder.Services.AddCors(options =>
{
    options.AddPolicy("AllowSpecificOrigin",
        builder =>
        {
            builder.WithOrigins("http://localhost:55212")
                   .AllowAnyHeader()
                   .AllowAnyMethod();
        });
});
var app = builder.Build();

// Configure the HTTP request pipeline.
if (app.Environment.IsDevelopment())
{
    app.UseSwagger();
    app.UseSwaggerUI();
}
else
{  
   app.UseMiddleware<GlobalExceptionMiddleware>();
}
app.UseSerilogRequestLogging();
app.UseCors("AllowSpecificOrigin");
app.UseAuthorization();
app.MapControllers();

app.Run();
