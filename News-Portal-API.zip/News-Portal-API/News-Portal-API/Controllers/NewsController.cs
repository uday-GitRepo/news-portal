﻿using AutoMapper;
using Microsoft.AspNetCore.Cors;
using Microsoft.AspNetCore.Mvc;
using News_Portal_API.Contracts;
using News_Portal_API.DTOs;
using News_Portal_API.Models;
using Newtonsoft.Json;
using Microsoft.Extensions.Caching.Memory;

namespace News_Portal_API.Controllers
{
    
    [ApiController]
    [Route("api/[controller]")]
    [EnableCors("AllowSpecificOrigin")]
    public class NewsController : ControllerBase
    {
        private readonly INewsArticleRepository _newsArticleRepository;
        private readonly ICategoryRepository _categoryRepository;
        private readonly IMemoryCache _cache;
        private readonly IMapper _mapper;
        private readonly string cacheKey = "Categories";
        public NewsController(INewsArticleRepository newsArticleRepository, ICategoryRepository categoryRepository, IMapper mapper, IMemoryCache cache) 
        {
            this._newsArticleRepository = newsArticleRepository;
            this._categoryRepository = categoryRepository;
            this._mapper= mapper;
            _cache = cache;
        }

       
        [HttpGet("GetNewsArticle/{id}")]
        public async Task<ActionResult<GetNewArticleDetailsDto>> GetNewsArticle([FromRoute]int id)
        {
            var newsArticle = await this._newsArticleRepository.GetAsync(id);

            if (newsArticle == null)
            {
                
                return BadRequest($"NewsArticle {id} is not found.");
            }

            var categoryDetailsDto = _mapper.Map<GetNewArticleDetailsDto>(newsArticle);

            return Ok(categoryDetailsDto);
        }


        [HttpGet("GetAllNewsArticle")]

        public async Task<ActionResult<GetNewArticleDetailsDto>> GetAllNewsArticle([FromQuery]Paging pageParams)
        {
            var newsArticle = await this._newsArticleRepository.GeAllAsync(pageParams);
            var records = _mapper.Map<List<NewArticleDetailsDto>>(newsArticle);
            var totalRecords= await this._newsArticleRepository.GetCountAsync(new Paging { FilterValue= pageParams.FilterValue, Skip=0,Take=0});
            return Ok(new GetNewArticleDetailsDto() { NewArticleDetails=records, TotalRecords= totalRecords});
        }

        [HttpPost("CreateNewsArticle")]
        public async Task<ActionResult<NewsArticle>> CreateNewsArticle([FromBody]CreateNewArticleDetailsDto createNewArticleDetailsDto)
        {
            var newsArticle = _mapper.Map<NewsArticle>(createNewArticleDetailsDto);
            newsArticle.Category = null;
            await this._newsArticleRepository.CreateAsync(newsArticle);

            return CreatedAtAction("GetNewsArticle", new { id = newsArticle.Id }, newsArticle);
        }

        [HttpPut("UpdateNewsArticle")]
        public async Task<IActionResult> UpdateNewsArticle(int id, UpdateNewArticleDetailsDto updateNewArticleDetailsDto)
        {
            if (id != updateNewArticleDetailsDto.Id)
            {
                return BadRequest("Invalid NewArticle Id");
            }

            var newsArticle = await _newsArticleRepository.GetAsync(id);

            if (newsArticle == null)
            {
                throw new Exception($"NewsArticle {id} is not found.");
            }

            updateNewArticleDetailsDto.CreatedOn = newsArticle.CreatedOn;
            _mapper.Map(updateNewArticleDetailsDto, newsArticle);
           

            try
            {
                await _newsArticleRepository.UpdateAsync(newsArticle);
            }
            catch (Exception)
            {
                throw new Exception($"Error occured while updating NewsArticle {id}.");
            }

            return NoContent();
        }

        [HttpDelete("DeleteNewsArticle")]
        public async Task<IActionResult> DeleteNewsArticle(int id)
        {
            await _newsArticleRepository.DeleteAsync(id);
            return NoContent();
        }

        [HttpGet("GetCategories")]
        public async Task<ActionResult<List<GeCategoryDto>>> GetCategories()
        {
            if (_cache.TryGetValue(cacheKey, out string? cachedValue))
            {
                return Ok(JsonConvert.DeserializeObject<List<Category>>(cachedValue ?? string.Empty));
            }
            else
            {
                var categories = await this._categoryRepository.GeAllAsync();
                var records = _mapper.Map<List<GeCategoryDto>>(categories);
                _cache.Set(cacheKey, JsonConvert.SerializeObject(records), new MemoryCacheEntryOptions
                {
                    AbsoluteExpirationRelativeToNow = TimeSpan.FromMinutes(20)
                });

                return Ok(records);
            }
            
            
        }

    }
}
