﻿namespace News_Portal_API.Models
{
    public partial class NewsArticle
    {
        public NewsArticle()
        {
            Category = new Category();
        }

        public int Id { get; set; }
        public string Title { get; set; } = null!;
        public string Description { get; set; } = null!;
        public int CategoryId { get; set; }
        public DateTime CreatedOn { get; set; }

        public virtual Category Category { get; set; }
    }
}
