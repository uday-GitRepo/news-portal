﻿
using Microsoft.EntityFrameworkCore;
using News_Portal_API.Contracts;
using News_Portal_API.Models;

namespace News_Portal_API.Repository
{
    public class CategoryRepository : ICategoryRepository
    {
        private readonly NewsArticleContext _context;

        public CategoryRepository(NewsArticleContext context) 
        {
            this._context = context;
        }
      

        public async Task<List<Category>> GeAllAsync()
        {
            return await _context.Categories.ToListAsync();
        }

     }
}
