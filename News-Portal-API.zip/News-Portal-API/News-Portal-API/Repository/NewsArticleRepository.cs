﻿
using Microsoft.EntityFrameworkCore;
using News_Portal_API.Contracts;
using News_Portal_API.DTOs;
using News_Portal_API.Models;
using News_Portal_API.Utils;
using System.Linq.Dynamic.Core;

namespace News_Portal_API.Repository
{
    public class NewsArticleRepository : INewsArticleRepository
    {
        private readonly NewsArticleContext _context;

        public NewsArticleRepository(NewsArticleContext context) 
        {
            this._context = context;
        }
        public async Task<NewsArticle> CreateAsync(NewsArticle article)
        {
           await _context.NewsArticles.AddAsync(article);
           await _context.SaveChangesAsync();
           return article;
        }

        public async Task DeleteAsync(int Id)
        {
            var newsArticle = await GetAsync(Id);
            if (newsArticle is null)
            {
                throw new Exception($"NewsArticle {Id} is not found.");
            }
            _context.Set<NewsArticle>().Remove(newsArticle);
            await _context.SaveChangesAsync();
        }

        public async Task<List<NewsArticle>> GeAllAsync(Paging pageParams)
        {
            var pagingData = CommonUtilities.GetPagingDetails(pageParams);
            return await _context.NewsArticles.Include(x => x.Category)
                .OrderByDescending(n => n.CreatedOn)
                .Where(pagingData.filterConsition, pageParams.FilterValue)
                .Skip(pagingData.pageNumber)
                .Take(pagingData.pageSize)               
                .ToListAsync();
        }

       

        public async Task<NewsArticle?> GetAsync(int id)
        {
            if (id == 0)
            {
                return null;
            }

            return await _context.NewsArticles.FindAsync(id);
        }

        public async Task<int> GetCountAsync(Paging pageParams)
        {
            var pagingData=CommonUtilities.GetPagingDetails(pageParams);
            return await _context.NewsArticles.Include(x => x.Category)
                .Where(pagingData.filterConsition, pageParams.FilterValue)               
                .CountAsync();
        }

        public async Task UpdateAsync(NewsArticle article)
        {
            _context.Update(article);
            await _context.SaveChangesAsync();
        }


    }
}
