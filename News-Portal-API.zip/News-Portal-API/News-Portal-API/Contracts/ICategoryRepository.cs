﻿using News_Portal_API.Models;

namespace News_Portal_API.Contracts
{
    public interface ICategoryRepository
    {      
        Task<List<Category>> GeAllAsync();
    }
}
