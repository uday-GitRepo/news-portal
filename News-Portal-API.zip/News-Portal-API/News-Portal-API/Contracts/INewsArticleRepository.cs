﻿using News_Portal_API.DTOs;
using News_Portal_API.Models;

namespace News_Portal_API.Contracts
{
    public interface INewsArticleRepository
    {
        Task<NewsArticle?> GetAsync(int id);
        Task<List<NewsArticle>> GeAllAsync(Paging pageParams);

        Task<NewsArticle> CreateAsync(NewsArticle article);

        Task<Int32> GetCountAsync(Paging pageParams);

        Task DeleteAsync(int Id);

        Task UpdateAsync(NewsArticle article);
    }
}
