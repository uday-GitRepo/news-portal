﻿using News_Portal_API.DTOs;

namespace News_Portal_API.Utils
{
    public static class CommonUtilities
    {
        public static (int pageNumber, int pageSize, string filterConsition) GetPagingDetails(Paging pageParams)
        {
            var filteConition = string.IsNullOrEmpty(pageParams.FilterValue) ? "1==1" : "Title.Contains(@0) || Description.Contains(@0) || Category.CategoryName.Contains(@0)";
            var skip = pageParams.Skip == 0 ? 1 : pageParams.Skip;
            var take = pageParams.Take == 0 ? int.MaxValue : pageParams.Take;
            var finalSkipValue = (skip - 1) * take;

            return (finalSkipValue, take,filteConition);
        }
    }
}
