﻿using AutoMapper;
using News_Portal_API.DTOs;
using News_Portal_API.Models;

namespace News_Portal_API.Configuration
{
    public class MapperConfig:Profile
    {
        public MapperConfig()
        {
            CreateMap<NewArticleDetailsDto, NewsArticle>().ReverseMap().ForMember(d => d.CategoryName, opt => opt.MapFrom(s => s.Category.CategoryName));

            CreateMap<CreateNewArticleDetailsDto, NewsArticle>().ReverseMap();

            CreateMap<UpdateNewArticleDetailsDto, NewsArticle>().ReverseMap();

            CreateMap<GeCategoryDto, Category>().ReverseMap();
        }
    }
}
